//
//  ReviewViewController.swift
//  NapQuestAlpha
//
//  Created by Hartzell, Weston C on 11/26/16.
//  Copyright © 2016 Hartzell, Weston C. All rights reserved.
//

// MARK: This view is for the individual reviews

import UIKit

class ReviewViewController: UIViewController {

    @IBOutlet weak var indvReviewText: UITextView!
    
    var review_text: String?
    
    @IBAction func indvReviewBackButton(sender: AnyObject) {
        self.performSegueWithIdentifier("unwindFromIndvReview:", sender: self)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        indvReviewText.text = review_text
        

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
