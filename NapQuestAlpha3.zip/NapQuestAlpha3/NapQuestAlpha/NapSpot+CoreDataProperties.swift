//
//  NapSpot+CoreDataProperties.swift
//  NapQuestAlpha
//
//  Created by Grecia Reyna on 12/5/16.
//  Copyright © 2016 Hartzell, Weston C. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

import Foundation
import CoreData

extension NapSpot {

    @NSManaged var rating: String?
    @NSManaged var picture: String?
    @NSManaged var name: String?
    @NSManaged var heart: String?

}
