//
//  FavoritesTableViewController.swift
//  NapQuestAlpha
//
//  Created by Grecia Reyna on 12/5/16.
//  Copyright © 2016 Hartzell, Weston C. All rights reserved.
//

import UIKit
import CoreData

class FavoritesTableViewController: UITableViewController {

    // MARK: Properties
    var favorite_spots = [NSManagedObject]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.cellLayoutMarginsFollowReadableWidth = false
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return favorite_spots.count
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cellIdentifier = "FavoritesTableViewCell"
        let cell = tableView.dequeueReusableCellWithIdentifier(cellIdentifier, forIndexPath: indexPath) as! FavoritesTableViewCell
        let favorite_spot = favorite_spots[indexPath.row]
        
        cell.favoriteLocationLabel.text = favorite_spot.valueForKey("name") as? String
        cell.favoriteRatingLabel.text = favorite_spot.valueForKey("rating") as? String
        cell.favoriteImageView.image = UIImage(named:(favorite_spot.valueForKey("name") as? String)!)
        //cell.cellImage.image = UIImage(named: (adventurer.valueForKey("portrait") as! String?)!)
        
        return cell
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        
        let appDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
        let managedContext = appDelegate.managedObjectContext
        let fetchRequest = NSFetchRequest(entityName: "NapSpot")
        do {
            let results = try managedContext.executeFetchRequest(fetchRequest)
            favorite_spots = results as! [NSManagedObject]
            tableView.reloadData()
        } catch let error as NSError {
            print("Could not fetch \(error), \(error.userInfo)")
        }
    }
    
    override func tableView(tableView: UITableView, willDisplayCell cell: UITableViewCell, forRowAtIndexPath indexPath: NSIndexPath) {
        if cell.respondsToSelector(Selector("setSeparatorInset:")){
            cell.separatorInset = UIEdgeInsetsZero
        }
        if cell.respondsToSelector(Selector("setPreservesSuperviewLayoutMargins:")) {
            cell.preservesSuperviewLayoutMargins = false
        }
        if cell.respondsToSelector(Selector("setLayoutMargins:")){
            cell.layoutMargins = UIEdgeInsetsZero
        }
    }
    
    override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
}