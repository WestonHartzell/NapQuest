//
//  NapSpot.swift
//  NapQuestAlpha
//
//  Created by Grecia Reyna on 12/5/16.
//  Copyright © 2016 Hartzell, Weston C. All rights reserved.
//

import UIKit
import CoreData

class NapSpot: NSManagedObject {

}
