//
//  CellCollectionViewCell.swift
//  NapQuestAlpha
//
//  Created by Hartzell, Weston C on 12/4/16.
//  Copyright © 2016 Hartzell, Weston C. All rights reserved.
//

import UIKit

class CellCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageView: UIImageView!
}
