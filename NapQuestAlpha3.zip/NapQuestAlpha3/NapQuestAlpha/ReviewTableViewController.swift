//
//  ReviewTableViewController.swift
//  NapQuestAlpha
//
//  Created by Hartzell, Weston C on 11/19/16.
//  Copyright © 2016 Hartzell, Weston C. All rights reserved.
// https://ashfurrow.com/blog/putting-a-uicollectionview-in-a-uitableviewcell-in-swift/
// MARK: This view is for the list of reviews at a location

import UIKit

class ReviewTableViewController: UITableViewController {
    
    var ratingList: [AnyObject] = []
    var reviewList: [AnyObject] = []
    var locName: String = ""
    var relevantIndex: Int?
    
    @IBOutlet weak var reviewLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let requestURL: NSURL = NSURL(string: "https://jsonblob.com/api/jsonBlob/3a7c9627-b53b-11e6-871b-87ffac99a466")!
        let URLRequest: NSMutableURLRequest = NSMutableURLRequest(URL: requestURL)
        let session = NSURLSession.sharedSession()
        let task = session.dataTaskWithRequest(URLRequest) {
            (data, response, error) -> Void in
            let httpResponse = response as! NSHTTPURLResponse
            let statusCode = httpResponse.statusCode
            
            if(statusCode == 200) {
                
                do {
                    let json = try NSJSONSerialization.JSONObjectWithData(data!, options: .AllowFragments)
                    
                    if let locations = json["locations"] as? [[String: AnyObject]] {
                        var location = locations[self.relevantIndex!]
                                    if let name = location["location"] as? String {
                                        self.locName = name
                                        if let ratings = location["rating"] as? [AnyObject] {
                                            self.ratingList = ratings
                                            if let reviews = location["reviews"] as? [AnyObject] {
                                                self.reviewList = reviews
                                            }
                                        }
                                    }
                            }
                } catch {
                    print("error with Json: \(error)")
                }
            }
            dispatch_async(dispatch_get_main_queue(), { () -> Void in
                self.tableView.reloadData()
            })
        }
        task.resume()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
//        if section == 1 {
//            return 1
//        } else {
            return reviewList.count + 1
//        }
    }
    override func tableView(tableView: UITableView, willDisplayCell cell: UITableViewCell, forRowAtIndexPath indexPath: NSIndexPath) {
        guard let tableViewCell = cell as? CViewTableViewCell else { return }
        
        tableViewCell.setCollectionViewDataSourceDelegate(self, forRow:indexPath.row)
        
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        if indexPath.row == 0 {
            let cell = tableView.dequeueReusableCellWithIdentifier("CViewTableViewCell", forIndexPath: indexPath) as! CViewTableViewCell
            return cell
            
        } else {
        
            let cellIdentifier = "ReviewTableViewCell"
            let cell = tableView.dequeueReusableCellWithIdentifier(cellIdentifier, forIndexPath: indexPath) as! ReviewTableViewCell
        
            let rating = ratingList[indexPath.row - 1]
            let review = reviewList[indexPath.row - 1]
            cell.reviewLabel.text = review as? String
            cell.ratingLabel.text = rating as? String

        return cell
        }
    }
    
    override func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        if indexPath.section == 0 {
            if indexPath.row == 0 {
                return 200
            } else {
            return 100
            }
        } else {
            return 100
        }
    }
    // MARK: Collection View
    /*
    // Override to support conditional editing of the table view.
    override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        if editingStyle == .Delete {
            // Delete the row from the data source
            tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Fade)
        } else if editingStyle == .Insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(tableView: UITableView, moveRowAtIndexPath fromIndexPath: NSIndexPath, toIndexPath: NSIndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(tableView: UITableView, canMoveRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    
    // MARK: - Navigation
    @IBAction func unwindFromIndvReview (segue: UIStoryboardSegue) {}
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if segue.identifier == "toIndvReview" {
            let nextScene = segue.destinationViewController as! ReviewViewController
            if let indexPath = self.tableView.indexPathForSelectedRow {
                let review = reviewList[indexPath.row - 1]
                print(review)
                nextScene.review_text = review as! String
            }
        }
        
    }
    

}

extension ReviewTableViewController: UICollectionViewDataSource, UICollectionViewDelegate {
    func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 70
    }
    
    func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCellWithReuseIdentifier("cell", forIndexPath: indexPath) as! CellCollectionViewCell
        
        
        cell.backgroundColor = UIColor.redColor()
        
        return cell
    }
}