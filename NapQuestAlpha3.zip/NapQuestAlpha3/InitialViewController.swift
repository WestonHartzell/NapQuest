//
//  InitialTableViewController.swift
//  NapQuestAlpha
//
//  Created by S Coleman on 12/2/16.
//  Copyright © 2016 Hartzell, Weston C. All rights reserved.

//Content is based on tutorial located here:
//https://www.codementor.io/swift/tutorial/view-animations-ios-tutorial
//Mountain background source: http://www.traemcneely.com/2014/12/30/purple-animated-mountain-sun-nature-wallpaper/
import UIKit
import Alamofire

class InitialViewController: UIViewController {
    
    
    @IBOutlet weak var napLabel: UILabel!
    @IBOutlet weak var learnButton: UIButton!
    @IBOutlet weak var cloud1: UIImageView!
    @IBOutlet weak var cloud2: UIImageView!
    @IBOutlet weak var startButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
                startButton.layer.cornerRadius = 5
                learnButton.layer.cornerRadius = 5
        
        jsonhandling()
        
    }
    
    override func viewWillAppear(animated: Bool)
    {
        startButton.alpha = 0.0
        learnButton.alpha = 0.0
        
        //Setting alpha to clouds
        cloud1.alpha = 0.0
        cloud2.alpha = 0.0
        
    }
    
    override func viewDidAppear(animated: Bool) {
        //Achieving Fade-in animation with alpha
        UIView.animateWithDuration(1.0, delay: 2.0,
                                   options: [],
                                   animations: {
                                    self.startButton.alpha = 1.0
                                    self.learnButton.alpha = 1.0
            }, completion: nil)
 
        
        UIView.animateWithDuration(0.5, delay: 0.6, options: [], animations: {
            self.cloud1.alpha = 1.0
            }, completion: nil)
        
        UIView.animateWithDuration(0.5, delay: 0.8, options: [], animations: {
            self.cloud2.alpha = 1.0
            }, completion: nil)
        
        
        //Calling animateTheClouds()
        animateTheClouds(cloud1)
        animateTheClouds(cloud2)
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //function to add animation loop to clouds
    func animateTheClouds(cloud : UIImageView) {
        let cloudMovingSpeed = 20.0/view.frame.size.width
        let duration = (view.frame.size.width - cloud.frame.origin.x) * cloudMovingSpeed
        UIView.animateWithDuration(NSTimeInterval(duration), delay: 0.0, options: .CurveLinear, animations: {
            cloud.frame.origin.x = self.view.frame.size.width
            }, completion: {_ in
                cloud.frame.origin.x = -cloud.frame.size.width
                self.animateTheClouds(cloud)
        })
    }
    @IBAction func unwindFromInfo(segue: UIStoryboardSegue) {
        
    }
    
    
    
    func jsonhandling(){
        
        let url = "https://jsonblob.com/api/jsonblob/36176ceb-b9b6-11e6-871b-e99e5ebebd55"
        Alamofire.request(.GET, url).validate().responseJSON { response in
            switch response.result {
            case .Success(let data):
                var json = JSON(data)
                json["secondkey", 3] = "item34"
                //let first = json["secondkey"][0].stringValue
                //print(first)
                //print(json)
                
                
                
                var list: Array<JSON> = json["secondkey"].arrayValue
                list.append("item39")
                
                json["secondkey"] = JSON(list)
                print(json)
                
                let jarray = [json["secondkey"][3].stringValue, json["secondkey"][1].stringValue, json["secondkey"][2].stringValue, json["secondkey"][0].stringValue]
                var params: [String: AnyObject] = [:]
                params["firstkey"] = "it worked"
                params["secondkey"] = [json["secondkey"][3], json["secondkey"][1], json["secondkey"][2], json["secondkey"][0]] as? AnyObject
                
                
                
                let request: Request = Request()
                
                let url: NSURL = NSURL(string: "https://jsonblob.com/api/jsonblob/48a35784-b9f1-11e6-871b-bf46f9155d27")!
                let body: NSMutableDictionary = NSMutableDictionary()
                body.setValue("it worked", forKey: "firstkey")
                body.setValue(jarray, forKey: "secondkey")
                
                request.put(url, body: body, completionHandler: { data, response, error in
                    // code
                })
                
                /*
                 
                 Alamofire.request(.PUT, "https://jsonblob.com/api/jsonblob/48a35784-b9f1-11e6-871b-bf46f9155d27", parameters: params)
                 .response { (request, response, json, error) in
                 print(request)
                 print(response)
                 print(error)
                 }
                 
                 */
                /*
                 
                 
                 
                 Alamofire.request(.PUT, "https://jsonblob.com/api/jsonblob/48a35784-b9f1-11e6-871b-bf46f9155d27", parameters: ["foo": "bar", "parm2": "hi"])
                 .response { (request, response, json, error) in
                 print(request)
                 print(response)
                 print(error)
                 }
                 */
                
            case .Failure(let error):
                print("Request failed with error: \(error)")
            }
        }
        
        
        /*
         Alamofire.request(.GET, "https://jsonblob.com/api/jsonblob/36176ceb-b9b6-11e6-871b-e99e5ebebd55").responseJSON { response in
         //print(response.request)  // original URL request
         //print(response.response) // HTTP URL response
         //print(response.data)     // server data
         //print(response.result)   // result of response serialization
         
         
         if let JSON = response.result.value {
         print(JSON["secondkey"][0] as! NSArray)
         }
         }
         */
        /*
         Alamofire.request(.GET, "https://jsonblob.com/api/jsonblob/36176ceb-b9b6-11e6-871b-e99e5ebebd55").responseJSON { (response) in
         if let JSON = response.result.value{
         print(JSON)
         }
         }
         */
        
    }


}
