//
//  TableViewControllerCell.swift
//  NapQuestAlpha
//
//  Created by Grecia Reyna on 11/28/16.
//  Copyright © 2016 Hartzell, Weston C. All rights reserved.
//

import UIKit
import CoreData

class LocationTableViewCell: UITableViewCell {
    
    @IBOutlet weak var locationImage: UIImageView!
    @IBOutlet weak var favoritesButton: UIButton!
    @IBOutlet weak var photoImageView: UIImageView!
    @IBOutlet weak var locationLabel: UILabel!
    @IBOutlet weak var ratingview: UILabel!
    
    var napspots : [NapSpot] = []
    var isFavorite = NSUserDefaults.standardUserDefaults().boolForKey("isFavorite")
    
    func setFavoritesButton() {
        let appDelegate: AppDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
        //let context: NSManagedObjectContext = appDelegate.managedObjectContext
        //let entityDescription = NSEntityDescription.entityForName("NapSpot", inManagedObjectContext: context)
        let napSpotFetch = NSFetchRequest(entityName: "NapSpot")
        let name = locationLabel.text
        napSpotFetch.predicate = NSPredicate(format: "name == %@", name!)
        do {
        let fetchResults = try appDelegate.managedObjectContext.executeFetchRequest(napSpotFetch) as! [NapSpot]
            if fetchResults.count > 0 {
                favoritesButton.setImage(UIImage(named: fetchResults[0].heart!), forState: UIControlState.Normal)
            }
            else {
                favoritesButton.setImage(UIImage(named: "grey_heart"), forState: UIControlState.Normal)
            }
        }
        catch{
            print("Error!")
        }
    
        //let napspot = NapSpot(entity: entityDescription!, insertIntoManagedObjectContext: context)
        
        //favoritesButton.setImage(UIImage(named: napspot.heart!), forState: UIControlState.Normal)
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        // Configure the view for the selected state
    }

    @IBAction func favButtonTapped(sender: UIButton){
        if isFavorite == true {
            let image = UIImage(named: "grey_heart")
            let appDelegate: AppDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
            let context: NSManagedObjectContext = appDelegate.managedObjectContext
            //let entityDescription = NSEntityDescription.entityForName("NapSpot", inManagedObjectContext: context)
            //let napspot = NapSpot(entity: entityDescription!, insertIntoManagedObjectContext: context)
            
            //context.objectWithID("name")
            //var napSpotToDelete = napspot.valueForKey("name"))
            
            let napSpotFetch = NSFetchRequest(entityName: "NapSpot")
            
            /*do {
                let fetchedNapSpots = try context.executeFetchRequest(napSpotFetch) as! [NapSpot]
            } catch {
                fatalError("Failed to fetch employees: \(error)")
            }*/
            
            let name = locationLabel.text
            napSpotFetch.predicate = NSPredicate(format: "name == %@", name!)
            
            do{
                let fetchResults = try appDelegate.managedObjectContext.executeFetchRequest(napSpotFetch)
                if fetchResults.count>0 {
                    appDelegate.managedObjectContext.deleteObject(fetchResults[0] as! NSManagedObject)
                    try context.save()
                    print("Removed!")
                } else {
                }
            }catch{
                print("Error!")
            }

            favoritesButton.setImage(image, forState: UIControlState.Normal)
        } else {
            //let image = UIImage(named: "red_heart")
            let appDelegate: AppDelegate = UIApplication.sharedApplication().delegate as! AppDelegate
            let context: NSManagedObjectContext = appDelegate.managedObjectContext
            let entityDescription = NSEntityDescription.entityForName("NapSpot", inManagedObjectContext: context)
            
            let napspot = NapSpot(entity: entityDescription!, insertIntoManagedObjectContext: context)
            
            napspot.name = locationLabel.text
            napspot.rating = ratingview.text
            napspot.heart = "red_heart"
            
            do
            {
                try context.save()
                print("Appended!")
            }
            catch {
                print("Error!")
            }
            napspots.append(napspot)
            favoritesButton.setImage(UIImage(named: napspot.heart!), forState: UIControlState.Normal)
        }
        
        isFavorite = !isFavorite
        NSUserDefaults.standardUserDefaults().setBool(isFavorite, forKey: "isFavorite")
        NSUserDefaults.standardUserDefaults().synchronize()
    }

}
