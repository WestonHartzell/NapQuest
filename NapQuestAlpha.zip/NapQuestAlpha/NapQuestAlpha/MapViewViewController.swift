//
//  MapViewViewController.swift
//  NapQuestAlpha
//
//  Created by Hartzell, Weston C on 11/21/16.
//  Copyright © 2016 Hartzell, Weston C. All rights reserved.
//

import UIKit
import CoreLocation
import MapKit
import CoreData

class MapViewViewController: UIViewController, CLLocationManagerDelegate, MKMapViewDelegate {
    // MARK: Properties
    @IBOutlet weak var mapView: MKMapView!
    @IBAction func backToLoc(sender: AnyObject) {
        self.performSegueWithIdentifier("unwindMapToLoc", sender: self)
    }
    
    var locationManager = CLLocationManager()
    
    let regionRadius: CLLocationDistance = 1600
    func centerMapOnLocation(location: CLLocation) {
        let coordinateRegion = MKCoordinateRegionMakeWithDistance(location.coordinate, regionRadius * 2.0, regionRadius * 2.0)
        mapView.setRegion(coordinateRegion, animated: false)
    }
    // MARK: ----PULL NETWORK DATA HERE
    
    //    let data:NSManagedObject = []
    
    // MARK: View Controller
    override func viewDidLoad() {
        super.viewDidLoad()
        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()
        
        if CLLocationManager.locationServicesEnabled() {
            locationManager.desiredAccuracy = kCLLocationAccuracyHundredMeters
            locationManager.requestLocation()
        }
        
        mapView.delegate = self;
        mapView.showsUserLocation = true
        //mapView.userTrackingMode = .Follow //Moves view to user position
        let initialLocation = CLLocation(latitude: 30.28, longitude: -97.73)
        centerMapOnLocation(initialLocation)
        
        // MARK: Pins
        //        for i in 0...data.count
        let annotation = MKPointAnnotation()
        annotation.coordinate = CLLocationCoordinate2D(latitude: 30.28243, longitude: -97.7383)
        annotation.title = "PCL"
        annotation.subtitle = "Click (i) to go to PCL reviews"
        mapView.addAnnotation(annotation)
        
        //Add a custom pin to the map
        //let customCoordinate = CLLocationCoordinate2D(latitude: 30, longitude: -97)
        //let customAnnotation = CustomAnnotation(coordinate: customCoordinate, title: "A Custom Pin", image: (UIImage(named: "360bridge"))!)
        //mapView.addAnnotation(customAnnotation)
        
        
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        
        // Load data for pins
    }
    // MARK: Map View
    //    func mapView(mapView: MKMapView, viewForAnnotation annotation: MKAnnotation) -> MKAnnotationView? {
    //        if let annotation = annotation MKUserLocation {
    //            return nil
    //        }
    //
    //        let reuseID = "pin"
    //        var pinView = mapView.dequeueReusableAnnotationViewWithIdentifier(reuseID)
    //        if pinView == nil {
    //            pinView = MKAnnotationView(annotation: annotation, reuseIdentifier: reuseID)
    //            pinView?.canShowCallout = true
    //
    //            let rightButton: UIButton = UIButton(type: .DetailDisclosure)
    //            rightButton.titleForState(UIControlState.Normal)
    //
    //            pinView!.rightCalloutAccessoryView = rightButton as UIView
    //
    //        } else {
    //
    //            pinView?.annotation = annotation
    //        }
    //        return pinView
    //    }
    // MARK: CLLocationMangerDelegate
    func locationManager(manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        for location in locations {
            print(location)
        }
    }
    func locationManager(manager: CLLocationManager, didFailWithError error: NSError) {
        print(error)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
