//
//  ViewController.swift
//  NapQuestAlpha
//
//  Created by Hartzell, Weston C on 11/19/16.
//  Copyright © 2016 Hartzell, Weston C. All rights reserved.
//
// MARK: This view displays the map

import UIKit
import CoreLocation
import MapKit

class ViewController: UIViewController, CLLocationManagerDelegate, MKMapViewDelegate {
    // MARK: Properties
    @IBOutlet weak var mapView: MKMapView!
    
    var locationManager = CLLocationManager()
    
    let regionRadius: CLLocationDistance = 1600
    func centerMapOnLocation(location: CLLocation) {
        let coordinateRegion = MKCoordinateRegionMakeWithDistance(location.coordinate, regionRadius * 2.0, regionRadius * 2.0)
        mapView.setRegion(coordinateRegion, animated: false)
    }
    @IBAction func mapBackButton(sender: AnyObject) {
        self.performSegueWithIdentifier("unwindFromMap", sender: self)
    }

    // MARK: View Controller
    override func viewDidLoad() {
        super.viewDidLoad()
        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()
        
        if CLLocationManager.locationServicesEnabled() {
            locationManager.desiredAccuracy = kCLLocationAccuracyHundredMeters
            locationManager.requestLocation()
        }
        
        mapView.delegate = self;
        mapView.showsUserLocation = true
        //mapView.userTrackingMode = .Follow //Moves view to user position
        let initialLocation = CLLocation(latitude: 30.28, longitude: -97.73)
        centerMapOnLocation(initialLocation)
        //Add a default pin to the map
        let annotation = MKPointAnnotation()
        annotation.coordinate = CLLocationCoordinate2D(latitude: 30.26, longitude: -97.74)
        annotation.title = "Austin, TX"
        annotation.subtitle = "This is roughly where we are..."
        mapView.addAnnotation(annotation)
        
        //Add a custom pin to the map
        //let customCoordinate = CLLocationCoordinate2D(latitude: 30, longitude: -97)
        //let customAnnotation = CustomAnnotation(coordinate: customCoordinate, title: "A Custom Pin", image: (UIImage(named: "360bridge"))!)
        //mapView.addAnnotation(customAnnotation)
        
        

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: CLLocationMangerDelegate
    func locationManager(manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        for location in locations {
        print(location)
        }
    }
    func locationManager(manager: CLLocationManager, didFailWithError error: NSError) {
        print(error)
    }
}

