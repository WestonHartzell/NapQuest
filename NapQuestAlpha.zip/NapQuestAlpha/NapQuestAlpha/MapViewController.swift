//
//  ViewController.swift
//  NapQuestAlpha
//
//  Created by Hartzell, Weston C on 11/19/16.
//  Copyright © 2016 Hartzell, Weston C. All rights reserved.
//
// MARK: This view displays the map
// http://www.learnswiftonline.com/mini-tutorials/how-to-download-and-read-json/

import UIKit
import CoreLocation
import MapKit

class ViewController: UIViewController, CLLocationManagerDelegate, MKMapViewDelegate {
    // MARK: Properties
    @IBOutlet weak var mapView: MKMapView!
    
    var locationManager = CLLocationManager()
    
    let regionRadius: CLLocationDistance = 1600
    func centerMapOnLocation(location: CLLocation) {
        let coordinateRegion = MKCoordinateRegionMakeWithDistance(location.coordinate, regionRadius * 2.0, regionRadius * 2.0)
        mapView.setRegion(coordinateRegion, animated: false)
    }
    @IBAction func mapBackButton(sender: AnyObject) {
        self.performSegueWithIdentifier("unwindFromMap", sender: self)
    }

    // MARK: View Controller
    override func viewDidLoad() {
        super.viewDidLoad()
        locationManager.delegate = self
        locationManager.requestAlwaysAuthorization()
        
        if CLLocationManager.locationServicesEnabled() {
            locationManager.desiredAccuracy = kCLLocationAccuracyHundredMeters
            locationManager.requestLocation()
        }
        
        mapView.delegate = self;
        mapView.showsUserLocation = true
        //mapView.userTrackingMode = .Follow //Moves view to user position
        let initialLocation = CLLocation(latitude: 30.28, longitude: -97.73)
        centerMapOnLocation(initialLocation)
        //Add a default pin to the map
        let annotation = MKPointAnnotation()
        annotation.coordinate = CLLocationCoordinate2D(latitude: 30.26, longitude: -97.74)
        annotation.title = "Austin, TX"
        annotation.subtitle = "This is roughly where we are..."
        mapView.addAnnotation(annotation)
        
        //Add a custom pin to the map
        //let customCoordinate = CLLocationCoordinate2D(latitude: 30, longitude: -97)
        //let customAnnotation = CustomAnnotation(coordinate: customCoordinate, title: "A Custom Pin", image: (UIImage(named: "360bridge"))!)
        //mapView.addAnnotation(customAnnotation)
        
        let requestURL: NSURL = NSURL(string: "https://jsonblob.com/api/jsonBlob/8f1abefe-b4df-11e6-871b-2732c594a477")!
        let URLRequest: NSMutableURLRequest = NSMutableURLRequest(URL: requestURL)
        let session = NSURLSession.sharedSession()
        let task = session.dataTaskWithRequest(URLRequest) {
            (data, response, error) -> Void in
            let httpResponse = response as! NSHTTPURLResponse
            let statusCode = httpResponse.statusCode
            
            if(statusCode == 200) {
                
                do {
                    let json = try NSJSONSerialization.JSONObjectWithData(data!, options: .AllowFragments)
                    
                    if let locations = json["locations"] as? [[String: AnyObject]] {
                        for location in locations {
                            if let latitude = location["latitude"] as? Float {
                                if let longitude = location["longitude"] as? Float {
                                    if let name = location["location"] as? String {
                                        if let ratings = location["rating"] as? [AnyObject] {
                                            if let reviews = location["reviews"] {
                                                print(latitude, longitude, name, ratings[0], reviews[0])
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                } catch {
                    print("error with Json: \(error)")
                }
            }
        }
        task.resume()
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: CLLocationMangerDelegate
    func locationManager(manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        for location in locations {

        }
    }
    func locationManager(manager: CLLocationManager, didFailWithError error: NSError) {
        print(error)
    }
}

