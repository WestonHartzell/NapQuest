//
//  ViewController.swift
//  NapQuestAlpha
//
//  Created by Hartzell, Weston C on 11/19/16.
//  Copyright © 2016 Hartzell, Weston C. All rights reserved.
//
// MARK: This view displays the map
// http://www.learnswiftonline.com/mini-tutorials/how-to-download-and-read-json/

import UIKit
import CoreLocation
import MapKit

class ViewController: UIViewController, CLLocationManagerDelegate, MKMapViewDelegate {
    // MARK: Properties
    @IBOutlet weak var mapView: MKMapView!
    
    var locationManager = CLLocationManager()
    var latitudes: [AnyObject] = []
    var longitudes: [AnyObject] = []
    var locationNames: [AnyObject] = []
    var locationRatings: [AnyObject] = []
    let regionRadius: CLLocationDistance = 1600
    func centerMapOnLocation(location: CLLocation) {
        let coordinateRegion = MKCoordinateRegionMakeWithDistance(location.coordinate, regionRadius * 2.0, regionRadius * 2.0)
        mapView.setRegion(coordinateRegion, animated: false)
    }
    func pullData() {
        // Fetch JSON Data
        let requestURL: NSURL = NSURL(string: "https://jsonblob.com/api/jsonBlob/8f1abefe-b4df-11e6-871b-2732c594a477")!
        let URLRequest: NSMutableURLRequest = NSMutableURLRequest(URL: requestURL)
        let session = NSURLSession.sharedSession()
        let task = session.dataTaskWithRequest(URLRequest) {
            
            (data, response, error) -> Void in
            let httpResponse = response as! NSHTTPURLResponse
            let statusCode = httpResponse.statusCode
            
            if(statusCode == 200) {
                
                do {
                    let json = try NSJSONSerialization.JSONObjectWithData(data!, options: .AllowFragments)
                    
                    if let locations = json["locations"] as? [[String: AnyObject]] {
                        for location in locations {
                            if let latitude = location["latitude"] as? Float {
                                self.latitudes.append(latitude)
                                print(self.latitudes)
                                if let longitude = location["longitude"] as? Float {
                                    self.longitudes.append(longitude)
                                    if let name = location["location"] as? String {
                                        self.locationNames.append(name)
                                        if let ratings = location["rating"] as? [AnyObject] {
                                            for rating in ratings {
                                                self.locationRatings.append(rating)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                } catch {
                    print("error with Json: \(error)")
                }
            // DO ALL LOCAL SAVE DATA SHIT HERE
                self.addPinsToMap()
            }
        }
        task.resume()

    }
    @IBAction func mapBackButton(sender: AnyObject) {
        self.performSegueWithIdentifier("unwindFromMap", sender: self)
    }
    func addPinsToMap() {
        let numLocations = self.latitudes.count
        print(numLocations)
        for index in 0..<numLocations {
            print(index)
            let annotation = MKPointAnnotation()
            print(Double(self.latitudes[index] as! NSNumber))
            annotation.coordinate = CLLocationCoordinate2D(latitude: Double(self.latitudes[index] as! NSNumber), longitude: Double(self.longitudes[index] as! NSNumber))
            annotation.title = self.locationNames[index] as? String
            annotation.subtitle = "\(self.locationRatings[index])/5"
            mapView.addAnnotation(annotation)
        }

    }
    // MARK: View Controller
    override func loadView() {
        super.loadView()
        
            }

    override func viewDidLoad() {
        super.viewDidLoad()
        locationManager.delegate = self
        locationManager.requestAlwaysAuthorization()
        
        if CLLocationManager.locationServicesEnabled() {
            locationManager.desiredAccuracy = kCLLocationAccuracyHundredMeters
            locationManager.requestLocation()
        }
        
        mapView.delegate = self;
        mapView.showsUserLocation = true
        
        //mapView.userTrackingMode = .Follow //Moves view to user position
        let initialLocation = CLLocation(latitude: 30.28, longitude: -97.73)
        centerMapOnLocation(initialLocation)
        pullData()

        print(self.latitudes.count)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: CLLocationMangerDelegate
    func locationManager(manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        for location in locations {

        }
    }
    func locationManager(manager: CLLocationManager, didFailWithError error: NSError) {
        print(error)
    }
}

