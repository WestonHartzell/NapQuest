//
//  Spot.swift
//  NapQuestAlpha
//
//  Created by S Coleman on 11/20/16.
//  Copyright © 2016 Hartzell, Weston C. All rights reserved.
// Code based on Apple tutorial series found here:
// https://developer.apple.com/library/content/referencelibrary/GettingStarted/DevelopiOSAppsSwift/Lesson2.html#//apple_ref/doc/uid/TP40015214-CH5-SW1

import UIKit

class Spot {
    // MARK: Properties
    
    var name: String
    var photo: UIImage?
    var rating: Int
    
    init?(name: String, photo: UIImage?, rating: Int) {
        // Initialize stored properties.
        self.name = name
        self.photo = photo
        self.rating = rating
        
        // Initialization should fail if there is no name or if the rating is negative.
        if name.isEmpty || rating < 0 {
            return nil
        }
    }
    
    
}

