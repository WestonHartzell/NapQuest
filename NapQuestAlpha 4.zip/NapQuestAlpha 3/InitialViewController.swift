//
//  InitialTableViewController.swift
//  NapQuestAlpha
//
//  Created by S Coleman on 12/2/16.
//  Copyright © 2016 Hartzell, Weston C. All rights reserved.

//Content is based on tutorial located here:
//https://www.codementor.io/swift/tutorial/view-animations-ios-tutorial
//Mountain background source: http://www.traemcneely.com/2014/12/30/purple-animated-mountain-sun-nature-wallpaper/
import UIKit

class InitialViewController: UIViewController {
    
    
    @IBOutlet weak var napLabel: UILabel!
    
    
    @IBOutlet weak var cloud1: UIImageView!
    
    @IBOutlet weak var cloud2: UIImageView!
    
    @IBOutlet weak var startButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
                startButton.layer.cornerRadius = 5
        
    }
    
    override func viewWillAppear(animated: Bool)
    {
        startButton.alpha = 0.0
        
        //Setting alpha to clouds
        cloud1.alpha = 0.0
        cloud2.alpha = 0.0
        
    }
    
    override func viewDidAppear(animated: Bool) {
        //Achieving Fade-in animation with alpha
        UIView.animateWithDuration(1.0, delay: 2.0,
                                   options: [],
                                   animations: {
                                    self.startButton.alpha = 1.0
            }, completion: nil)
 
        
        UIView.animateWithDuration(0.5, delay: 0.6, options: [], animations: {
            self.cloud1.alpha = 1.0
            }, completion: nil)
        
        UIView.animateWithDuration(0.5, delay: 0.8, options: [], animations: {
            self.cloud2.alpha = 1.0
            }, completion: nil)
        
        
        //Calling animateTheClouds()
        animateTheClouds(cloud1)
        animateTheClouds(cloud2)
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //function to add animation loop to clouds
    func animateTheClouds(cloud : UIImageView) {
        let cloudMovingSpeed = 20.0/view.frame.size.width
        let duration = (view.frame.size.width - cloud.frame.origin.x) * cloudMovingSpeed
        UIView.animateWithDuration(NSTimeInterval(duration), delay: 0.0, options: .CurveLinear, animations: {
            cloud.frame.origin.x = self.view.frame.size.width
            }, completion: {_ in
                cloud.frame.origin.x = -cloud.frame.size.width
                self.animateTheClouds(cloud)
        })
    }


}
