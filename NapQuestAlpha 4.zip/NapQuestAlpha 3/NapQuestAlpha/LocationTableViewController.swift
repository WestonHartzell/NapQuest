//
//  LocationTableViewController.swift
//  NapQuestAlpha
//
//  Created by Hartzell, Weston C on 11/19/16.
//  Copyright © 2016 Hartzell, Weston C. All rights reserved.
//  MARK: This view displays the list of locations

import UIKit

class LocationTableViewController: UITableViewController {
    
    var spots = [Spot]()
    
    var ratingarray :[String] = []
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let requestURL: NSURL = NSURL(string: "https://jsonblob.com/api/jsonBlob/8f1abefe-b4df-11e6-871b-2732c594a477")!
        let URLRequest: NSMutableURLRequest = NSMutableURLRequest(URL: requestURL)
        let session = NSURLSession.sharedSession()
        let task = session.dataTaskWithRequest(URLRequest) {
            (data, response, error) -> Void in
            let httpResponse = response as! NSHTTPURLResponse
            let statusCode = httpResponse.statusCode
            
            if(statusCode == 200) {
                
                do {
                    let json = try NSJSONSerialization.JSONObjectWithData(data!, options: .AllowFragments)
                    
                    if let locations = json["locations"] as? [[String: AnyObject]] {
                        for location in locations {
                            if let latitude = location["latitude"] as? Float {
                                if let longitude = location["longitude"] as? Float {
                                    if let name = location["location"] as? String {
                                        self.ratingarray.append(name)
                                        if let ratings = location["rating"] as? [AnyObject] {
                                            if let reviews = location["reviews"] {
                                                print(latitude, longitude, name, ratings[0], reviews[0])

                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                    self.loadSpots()
                } catch {
                    print("error with Json: \(error)")
                }
            }
            self.loadSpots()
            dispatch_async(dispatch_get_main_queue(), { () -> Void in
                self.tableView.reloadData()
            })
        }
        task.resume()
        
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false
        
        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
    }
    
    
    func loadSpots() {
        for i in 0..<ratingarray.count {
            let photo = UIImage(named: "defaultPhoto")!
            let spot = Spot(name:ratingarray[i], photo: photo, rating: i + 1)!
            spots += [spot]
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Table view data source
    
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return spots.count
    }
    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        
        let cellIdentifier = "LocationTableViewCell"
        let cell = tableView.dequeueReusableCellWithIdentifier(cellIdentifier, forIndexPath: indexPath) as! LocationTableViewCell
        
        let spot = spots[indexPath.row]
        
        cell.locationLabel.text = spot.name
        //cell.photoImageView.image = spot.photo
        cell.ratingview.text = String(spot.rating)
        
        return cell
    }
    
    /*
     // Override to support conditional editing of the table view.
     override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
     // Return false if you do not want the specified item to be editable.
     return true
     }
     */
    
    /*
     // Override to support editing the table view.
     override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
     if editingStyle == .Delete {
     // Delete the row from the data source
     tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Fade)
     } else if editingStyle == .Insert {
     // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
     }
     }
     */
    
    /*
     // Override to support rearranging the table view.
     override func tableView(tableView: UITableView, moveRowAtIndexPath fromIndexPath: NSIndexPath, toIndexPath: NSIndexPath) {
     
     }
     */
    
    /*
     // Override to support conditional rearranging of the table view.
     override func tableView(tableView: UITableView, canMoveRowAtIndexPath indexPath: NSIndexPath) -> Bool {
     // Return false if you do not want the item to be re-orderable.
     return true
     }
     */
    
    
    // MARK: - Navigation
    @IBAction func unwindFromMap(segue: UIStoryboardSegue) {}
    @IBAction func unwindFromReviews (segue: UIStoryboardSegue) {}
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
    // Get the new view controller using segue.destinationViewController.
    // Pass the selected object to the new view controller.
        if segue.identifier == "locToReviews" {
            let nextScene = segue.destinationViewController as! ReviewTableViewController
            if let indexPath = self.tableView.indexPathForSelectedRow {
                nextScene.relevantIndex = indexPath.row
            }
        }
    }
    
    
}
